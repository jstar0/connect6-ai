package stud.g77;

public class G77Board extends core.board.Board {
    public G77Board(String name){
        this.name = name;
    }
    private String name;
}
