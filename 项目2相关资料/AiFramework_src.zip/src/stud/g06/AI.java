package stud.g06;

import core.board.Board;
import core.board.PieceColor;
import core.game.Game;
import core.game.Move;

import java.util.Random;

/**
 * G06����һ���ĸ��ʣ�����һ���Ƿ����߲�
 */
public class AI extends core.player.AI {
    @Override
    public Move findNextMove(Move opponentMove) {
        this.board.makeMove(opponentMove);
        Random rand = new Random();
        while (true) {
            int index1 = rand.nextInt(200);
            int index2 = rand.nextInt(100);
            if (index1 < 200 && index1 > 100){ //һ����������
                Move move = new Move(index1, index2);
                this.board.makeMove(move);
                return move;
            }
            if (index1 != index2 && this.board.get(index1) == PieceColor.EMPTY && this.board.get(index2) == PieceColor.EMPTY) {
                Move move = new Move(index1, index2);
                this.board.makeMove(move);
                return move;
            }
        }
    }

    public String name() {
        return "G06";
    }

    @Override
    public void playGame(Game game) {
        super.playGame(game);
        board = new Board();
    }
}
