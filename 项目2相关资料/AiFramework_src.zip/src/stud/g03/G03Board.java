package stud.g03;

public class G03Board extends core.board.Board {
    public G03Board(String name){
        this.name = name;
    }
    private String name;
}
