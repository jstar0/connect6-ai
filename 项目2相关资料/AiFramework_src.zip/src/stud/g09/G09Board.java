package stud.g09;

public class G09Board extends core.board.Board {
    public G09Board(String name){
        this.name = name;
    }
    private String name;
}
