package core.game.ui.connect6;

import core.game.timer.GameTimer;
import core.game.ui.GameUI;

import java.util.Observable;
//���������һ����̫���۵�GUI
public class UglyGUI implements GameUI {
    @Override
    public void setTimer(GameTimer bTimer, GameTimer wTimer) {

    }

    @Override
    public void update(Observable o, Object arg) {

    }
}
