package core.player;

import core.board.PieceColor;
import core.game.Game;
import core.game.GameResult;
import core.game.Move;
import core.game.timer.GameTimer;

import java.util.ArrayList;

/**
 * A generic Connect6 Player.
 * 
 * @author
 */
public abstract class Player implements Comparable<Player>, Cloneable, Runnable {

	public abstract boolean isManual();

	public abstract String name();
	private Thread me;
	private ArrayList<GameResult> gameResults = new ArrayList<>();

	// ���ӵ�ǰ���ֲ������ֵĽ��
	public void addGameResult(GameResult result) {
		gameResults.add(result);
	}

	public ArrayList<GameResult> gameResults() {
		return gameResults;
	}

	// ���㵱ǰ����������ֵ��ܵ÷֣���ʤ��2�֣�ƽ�ֵ�1�֣���ܵ�0��
	public int scores() {
		int scores = 0;
		for (GameResult result : gameResults) {
			scores += result.score(this.name());
		}
		return scores;
	}

	/**
	 * ��ǰ�����������opponent�����ֶ��Ľ��ͳ��
	 * ��ǰ����ִ��
	 * @param opponent ��ǰ���ֵĶ���
	 * @return
	 */
	public int[][] getGameStatistics(Player opponent){
		int[][] statistics = new int[2][3];
		int games = 0;
		for (GameResult result : gameResults) {
			if (result.getOpponent(this).equals(opponent)) {
				if (result.getFirst().equals(this)) {
					statistics[0][result.score(this.name())]++;
				}
				else if (result.getSecond().equals(this)) {
					statistics[1][result.score(this.name())]++;
				}
				games++;
			}
		}
		return games > 0 ? statistics : null;
	}

	public Thread start() {
		this.me = new Thread(this);
		this.me.start();
		return this.me;
	}

	public void run(){
		while (true){
			;
		}
	}

	public PieceColor getColor() {
		return _myColor;
	}

	/** A Player that will play MYCOLOR in GAME. */
	public void setColor(PieceColor myColor) {
		_myColor = myColor;
	}

	/** Return the game I am playing in. */
	public Game game() {
		return _game;
	}

	/** Join a game. */
	public void playGame(Game game) {
		_game = game;
		//��������Timer�ļ�����Ϊ�����ּ����Game
		timer.addObserver(_game);
	}

	/**
	 * Return a legal move for me according to my opponent's move, and at that
	 * moment, I am facing a board after the opponent's move. Abstract method to be
	 * implemented by subclasses.
	 */
	public abstract Move findMove(Move opponentMove) throws Exception;

	/** The game I am playing in. */
	private Game _game;

	/** The color of my pieces. */
	protected PieceColor _myColor;
	private GameTimer timer;	//���ֵļ�ʱ��
	@Override
	public int compareTo(Player arg0) {
		// TODO Auto-generated method stub
		return arg0.scores() - this.scores();
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException{
		return super.clone();
    }

	public void setTimer(GameTimer timer) {
		this.timer = timer;
	}
	
	public void stopTimer() {
		timer.stop();
	}
	public void startTimer() {
		timer.start();
	}

	public abstract String fullName();

	@Override
	public boolean equals(Object obj) {
		if (obj == this)
			return true;

		if (obj instanceof Player) {
			Player another = (Player) obj;
			return this.name().equals(another.name());
		}
		return false;
	}
}
